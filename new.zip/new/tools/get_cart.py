from langchain.tools import tool
from pydantic import BaseModel
from typing import List

# Define the CartItem model
class CartItem(BaseModel):
    product_id: int
    name: str
    quantity: int
    price: float  # Price per unit

# Define the return type model
class GetCartResponse(BaseModel):
    items: List[CartItem]
    total: float

# Tool implementation with return type
@tool("get_cart", return_direct=True)
def get_cart() -> GetCartResponse:
    """
    Dummy tool to fetch cart information.
    Returns a predefined list of sample cart items.
    """
    items = [
        CartItem(product_id=1, name="Laptop", quantity=1, price=1200.00),
        CartItem(product_id=2, name="Wireless Mouse", quantity=2, price=25.00),
        CartItem(product_id=3, name="Headphones", quantity=1, price=50.00),
    ]
    
    # Calculate the total cost
    total_cost = sum(item.quantity * item.price for item in items)
    
    return GetCartResponse(items=items, total=total_cost)


