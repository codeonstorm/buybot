# tools/add_to_cart.py

from langchain.tools import tool
from pydantic import BaseModel
from typing import Dict

# Define the CartItem model
class CartItem(BaseModel):
    product_id: int
    name: str
    quantity: int
    price: float

# Simulate a cart storage (can be replaced with a real database or session storage)
cart_db: Dict[int, CartItem] = {}

# Tool implementation for adding item to the cart
@tool("add_to_cart", return_direct=True)
def add_to_cart(product_id: int, quantity: int) -> str:
    """
    Adds a product to the cart. If the product is already in the cart,
    it updates the quantity.
    """
    # Dummy product data (In real case, fetch from DB or API)
    products_db = {
        1: {"name": "Laptop", "price": 1200.00},
        2: {"name": "Mouse", "price": 25.00},
        3: {"name": "Headphones", "price": 50.00},
    }
    
    product = products_db.get(product_id)
    if not product:
        return "Product not found."

    # If product is already in the cart, update quantity
    if product_id in cart_db:
        cart_db[product_id].quantity += quantity
    else:
        cart_db[product_id] = CartItem(
            product_id=product_id,
            name=product["name"],
            quantity=quantity,
            price=product["price"]
        )

    return f"Added {quantity} of {product['name']} to your cart."

