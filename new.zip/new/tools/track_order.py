# tools/track_order.py

from langchain.tools import tool
from typing import Dict

# Simulated order tracking data (In a real scenario, fetch from database or API)
orders_db: Dict[str, Dict] = {
    "ORD123": {"status": "Shipped", "estimated_delivery": "2024-12-05", "location": "Warehouse"},
    "ORD456": {"status": "Out for Delivery", "estimated_delivery": "2024-12-02", "location": "Local Hub"},
    "ORD789": {"status": "Delivered", "estimated_delivery": "2024-11-30", "location": "Customer Address"},
}

# Tool implementation
@tool("track_order", return_direct=True)
def track_order(order_id: str) -> str:
    """
    Tracks the status of an order by order ID.
    Returns the current status, location, and estimated delivery date.
    """
    order = orders_db.get(order_id)
    if not order:
        return "Order not found. Please check the order ID."
    
    status = order["status"]
    location = order["location"]
    estimated_delivery = order["estimated_delivery"]
    
    return (
        f"Order ID: {order_id}\n"
        f"Status: {status}\n"
        f"Current Location: {location}\n"
        f"Estimated Delivery: {estimated_delivery}"
    )
