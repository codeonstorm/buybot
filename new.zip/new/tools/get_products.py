from langchain.tools import tool

@tool
def get_products():
    """
    Dummy tool to fetch product information.
    Returns a predefined list of sample products.
    """
    products = [
        {"id": 1, "name": "Laptop", "price": "$1200", "availability": "In stock"},
        {"id": 2, "name": "Wireless Mouse", "price": "$25", "availability": "Out of stock"},
        {"id": 3, "name": "Mechanical Keyboard", "price": "$80", "availability": "In stock"},
        {"id": 4, "name": "Smartphone", "price": "$700", "availability": "In stock"},
        {"id": 5, "name": "Headphones", "price": "$50", "availability": "Limited stock"},
    ]
    return {"products": products}