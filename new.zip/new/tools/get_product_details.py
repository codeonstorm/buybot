from langchain.tools import tool
from pydantic import BaseModel
from typing import List

# Define the Product model
class ProductDetails(BaseModel):
    id: int
    name: str
    description: str
    price: float
    availability: str

# Tool implementation
@tool("get_product_details", return_direct=True)
def get_product_details(product_id: int) -> ProductDetails:
    """
    Fetches detailed information about a specific product.
    Returns dummy product details for demonstration.
    """
    # Dummy product data (in a real app, fetch from database)
    products_db = {
        1: {"name": "Laptop", "description": "High-performance laptop.", "price": 1200.00, "availability": "In stock"},
        2: {"name": "Mouse", "description": "Wireless optical mouse.", "price": 25.00, "availability": "Out of stock"},
        3: {"name": "Headphones", "description": "Noise-canceling headphones.", "price": 50.00, "availability": "Limited stock"},
    }

    product = products_db.get(product_id)
    if not product:
        return {"error": "Product not found."}
    
    return ProductDetails(id=product_id, **product)
