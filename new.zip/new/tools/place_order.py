from langchain.tools import tool

@tool
def place_order(product_id: int) -> str:
    """
    Book a product by its ID.

    Args:
        product_id (int): The ID of the product to book.

    Returns:
        str: A message indicating whether the order was successfully booked or not.
    """
 
    return f"product {product_id} successfully booked."
        # return f"No car rental found with ID {rental_id}."
