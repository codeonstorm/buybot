#  current working ......

from typing import Annotated
import os
from datetime import datetime

from typing_extensions import TypedDict
from langgraph.graph.message import add_messages

import json
# import requests
from langchain_core.messages import ToolMessage
from langchain.tools import Tool

import random
from langchain_core.tools import tool

from langchain_core.prompts import PromptTemplate

from typing import Annotated

from typing_extensions import TypedDict
from langgraph.graph.message import AnyMessage, add_messages

# agent
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable, RunnableLambda, RunnableConfig

# Define Graph
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.prebuilt import ToolNode, tools_condition

from tools import get_cart, get_products, place_order, track_order, get_product_details, add_to_cart

def handle_tool_error(state) -> dict:
    error = state.get("error")
    tool_calls = state["messages"][-1].tool_calls
    return {
        "messages": [
            ToolMessage(
                content=f"Error: {repr(error)}\n please fix your mistakes.",
                tool_call_id=tc["id"],
            )
            for tc in tool_calls
        ]
    }


def create_tool_node_with_fallback(tools: list) -> dict:
    return ToolNode(tools).with_fallbacks(
        [RunnableLambda(handle_tool_error)], exception_key="error"
    )


def _print_event(event: dict, _printed: set, max_length=1500):
    current_state = event.get("dialog_state")
    if current_state:
        print("Currently in: ", current_state[-1])
    message = event.get("messages")
    if message:
        if isinstance(message, list):
            message = message[-1]
        if message.id not in _printed:
            msg_repr = message.pretty_repr(html=True)
            if len(msg_repr) > max_length:
                msg_repr = msg_repr[:max_length] + " ... (truncated)"
            print(msg_repr)
            _printed.add(message.id)

# Part 1: Zero-shot Agent
# State¶
class State(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]

# Agent
class Assistant:
    def __init__(self, runnable: Runnable):
        self.runnable = runnable

    def __call__(self, state: State, config: RunnableConfig):
        while True:
            configuration = config.get("configurable", {})
            customer_id = configuration.get("customer_id", None)
            state = {**state, "user_info": customer_id}
            result = self.runnable.invoke(state)
            # If the LLM happens to return an empty response, we will re-prompt it
            # for an actual response.
            if not result.tool_calls and (
                not result.content
                or isinstance(result.content, list)
                and not result.content[0].get("text")
            ):
                messages = state["messages"] + [("user", "Respond with a real output.")]
                state = {**state, "messages": messages}
            else:
                break
        return {"messages": result}
    
llm = ChatOllama(model="llama3.2", temperature=0.5)


primary_assistant_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a helpful customer support assistant for ecommerce. "
            " For basic or general queries like greetings, farewells relpy in two to three words only ."
            " Use the provided tools to assist the user's queries. only if relevent tools found"
            " Note: Please reply in a concise way as much as possible."
            # "\n\nIf the user needs help, and none of your tools are appropriate for it, then Do not waste the user"
            
            # " When searching, be persistent. Expand your query bounds if the first search returns no results. "
            # " If a search comes up empty, expand your search before giving up."
            "\n\nCurrent user:\n<User>\n{user_info}\n</User>"
            "\nCurrent time: {time}.",
        ),
        ("placeholder", "{messages}"),
    ]
).partial(time=datetime.now)

part_1_tools = [
    get_products,
    get_product_details,
    place_order,
    track_order,
    get_cart,
    add_to_cart
]
part_1_assistant_runnable = primary_assistant_prompt | llm.bind_tools(part_1_tools)

# Define Graph
builder = StateGraph(State)


# Define nodes: these do the work
builder.add_node("assistant", Assistant(part_1_assistant_runnable))
builder.add_node("tools", create_tool_node_with_fallback(part_1_tools))
# Define edges: these determine how the control flow moves
builder.add_edge(START, "assistant")
builder.add_conditional_edges(
    "assistant",
    tools_condition,
)
builder.add_edge("tools", "assistant")

# The checkpointer lets the graph persist its state
# this is a complete memory for the entire graph.
memory = MemorySaver()
part_1_graph = builder.compile(checkpointer=memory)




# output
# from IPython.display import Image

# try:
#     # Generate the image from the graph
#     image_data = part_1_graph.get_graph(xray=True).draw_mermaid_png()
    
#     # Save the image data to a file
#     with open("output_graph.png", "wb") as f:
#         f.write(image_data)
    
#     print("Graph saved as 'output_graph.png'")
# except Exception as e:
#     print(f"An error occurred: {e}")



# Example Conversation
question = "what's the status of my order ORD123?"
config = {
    "configurable": {
        # The customer_id is used in tools to
        # fetch the customer' flight information
        "customer_id": "34429887242",
        # Checkpoints are accessed by thread_id
        "thread_id": 84356,
    }
}
events = part_1_graph.invoke(
    {"messages": ("user", question)}, config, stream_mode="values"
)

 
for event in events.get('messages'):
    if event.response_metadata:
        if "tool_calls" not in event.response_metadata.get('message'):
            print(event.response_metadata.get('message').get('content'))


    

# _printed = set()
# for event in events:
#     _print_event(event, _printed)

 
 



# def stream_graph_updates(user_input: str):
#     config = {
#         "configurable": {
#             # The customer_id is used in tools to
#             # fetch the customer' flight information
#             "customer_id": "34429887242",
#             # Checkpoints are accessed by thread_id
#             "thread_id": 84356,
#         }
#     }

#     _printed = set()
#     # stream_mode="values"
#     for event in part_1_graph.stream({"messages": ("user", user_input)}, config):
#         print(event)
#         # _print_event(event, _printed)
#         # for value in event.values():
#         #     print("Assistant:", value["messages"][-1].content)


# while True:
#     try:
#         user_input = input("User: ")
#         if user_input.lower() in ["quit", "exit", "q"]:
#             print("Goodbye!")
#             break

#         stream_graph_updates(user_input)
#     except:
#         # fallback if input() is not available
#         print('I am busy!, please try after some time')
#         break