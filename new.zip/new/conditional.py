#  current working ......

from typing import Annotated
import os
from datetime import datetime

from typing_extensions import TypedDict
from langgraph.graph.message import add_messages

import json
# import requests
from langchain_core.messages import ToolMessage
from langchain.tools import Tool

import random
from langchain_core.tools import tool

from langchain_core.prompts import PromptTemplate

from typing import Annotated

from typing_extensions import TypedDict
from langgraph.graph.message import AnyMessage, add_messages

# agent
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable, RunnableLambda, RunnableConfig

# Define Graph
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.prebuilt import ToolNode, tools_condition



 
@tool
def current_time_tool(location: str = "") -> str:
    """Get the current system time. If no location is provided, use default location as 'Woodbury, Minnesota'.
    
    This tool simulates retrieving the system time by randomly selecting from three possible outcomes: morning, afternoon, or evening. 
    The chance of each outcome is equal (1/3). If the random check fails, it may return an unexpected result to simulate real-world unpredictable conditions.
    
    Args:
        location (str): Optional. The name of the location for which to retrieve the system time. It defaults to Minnesota if not provided.  
        
    Returns:
        str: A string describing the current system time in the specified or default location, randomly chosen from three possible outcomes.
    """
    return
    # start a random check for 1/3 of times to simulate a failure
    if random.randint(0, 2) == 0 :
        return "2:00 AM"
    elif random.randint(0, 2) == 1:
        return "3:00 PM"
    else:
        return ""

@tool
def get_weather(location: str):
    """Call to get the current weather."""
    return
    if location.lower() in ["sf", "san francisco"]:
        return "It's 60 degrees and foggy."
    else:
        return "It's 90 degrees and sunny."

@tool
def get_coolest_cities():
    """Get a list of coolest cities argument not require"""
    return 
    return "nyc, sf"


@tool
def fetch_user_flight_information(config: RunnableConfig) -> list[dict]:
    """Fetch all tickets for the user along with corresponding flight information and seat assignments.

    Returns:
        A list of dictionaries where each dictionary contains the ticket details,
        associated flight details, and the seat assignments for each ticket belonging to the user.
    """
    return [
        {
            "ticket_id": "TK123456",
            "user_id": "U7890",
            "flight": {
                "flight_number": "AI202",
                "airline": "Air India",
                "departure": {
                    "city": "New Delhi",
                    "airport": "Indira Gandhi International Airport (DEL)",
                    "time": "2024-06-01T10:00:00"
                },
                "arrival": {
                    "city": "Mumbai",
                    "airport": "Chhatrapati Shivaji Maharaj International Airport (BOM)",
                    "time": "2024-06-01T12:30:00"
                },
            },
            "seat_assignment": {
                "seat_number": "12A",
                "class": "Economy"
            },
            "status": "confirmed"
        },
        {
            "ticket_id": "TK654321",
            "user_id": "U7890",
            "flight": {
                "flight_number": "BA256",
                "airline": "British Airways",
                "departure": {
                    "city": "London",
                    "airport": "Heathrow Airport (LHR)",
                    "time": "2024-06-05T15:45:00"
                },
                "arrival": {
                    "city": "New York",
                    "airport": "John F. Kennedy International Airport (JFK)",
                    "time": "2024-06-05T19:30:00"
                },
            },
            "seat_assignment": {
                "seat_number": "5D",
                "class": "Business"
            },
            "status": "confirmed"
        }
    ]

# Example usage:
# flights = fetch_user_flight_information(config)
# print(flights)



def handle_tool_error(state) -> dict:
    error = state.get("error")
    tool_calls = state["messages"][-1].tool_calls
    return {
        "messages": [
            ToolMessage(
                content=f"Error: {repr(error)}\n please fix your mistakes.",
                tool_call_id=tc["id"],
            )
            for tc in tool_calls
        ]
    }


def create_tool_node_with_fallback(tools: list) -> dict:
    return ToolNode(tools).with_fallbacks(
        [RunnableLambda(handle_tool_error)], exception_key="error"
    )


def _print_event(event: dict, _printed: set, max_length=1500):
    current_state = event.get("dialog_state")
    if current_state:
        print("Currently in: ", current_state[-1])
    message = event.get("messages")
    if message:
        if isinstance(message, list):
            message = message[-1]
        if message.id not in _printed:
            msg_repr = message.pretty_repr(html=True)
            if len(msg_repr) > max_length:
                msg_repr = msg_repr[:max_length] + " ... (truncated)"
            print(msg_repr)
            _printed.add(message.id)




# Part 1: Zero-shot Agent
# State¶
class State(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    user_info: str

# Agent
class Assistant:
    def __init__(self, runnable: Runnable):
        self.runnable = runnable
    
    def __call__(self, state: State, config: RunnableConfig):
        while True:
            result = self.runnable.invoke(state)
            # If the LLM happens to return an empty response, we will re-prompt it
            # for an actual response.
            if not result.tool_calls and (
                not result.content
                or isinstance(result.content, list)
                and not result.content[0].get("text")
            ):
                messages = state["messages"] + [("user", "Respond with a real output.")]
                state = {**state, "messages": messages}
            else:
                break
        return {"messages": result}
    
llm = ChatOllama(model="llama3.2", temperature=0)

assistant_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a helpful customer support assistant for Swiss Airlines. "
            " Use the provided tools to search for flights, company policies, and other information to assist the user's queries. "
            " When searching, be persistent. Expand your query bounds if the first search returns no results. "
            " If a search comes up empty, expand your search before giving up."
            "\n\nCurrent user:\n<User>\n{user_info}\n</User>"
            "\nCurrent time: {time}.",
        ),
        ("placeholder", "{messages}"),
    ]
).partial(time=datetime.now)

part_1_tools = [
    get_coolest_cities,
    fetch_user_flight_information,
    get_weather
]
part_1_assistant_runnable = assistant_prompt | llm.bind_tools(part_1_tools)

# Define Graph
builder = StateGraph(State)

def user_info(state: State):
    return {"user_info": fetch_user_flight_information.invoke({})}


# NEW: The fetch_user_info node runs first, meaning our assistant can see the user's flight information without
# having to take an action
builder.add_node("fetch_user_info", user_info)
builder.add_edge(START, "fetch_user_info")
builder.add_node("assistant", Assistant(part_1_assistant_runnable))
builder.add_node("tools", create_tool_node_with_fallback(part_1_tools))
builder.add_edge("fetch_user_info", "assistant")
builder.add_conditional_edges(
    "assistant",
    tools_condition,
)
builder.add_edge("tools", "assistant")

memory = MemorySaver()
part_2_graph = builder.compile(
    checkpointer=memory,
    # NEW: The graph will always halt before executing the "tools" node.
    # The user can approve or reject (or even alter the request) before
    # the assistant continues
    interrupt_before=["tools"],
)



# output
# from IPython.display import Image

# try:
#     # Generate the image from the graph
#     image_data = part_2_graph.get_graph(xray=True).draw_mermaid_png()
    
#     # Save the image data to a file
#     with open("output_graph.png", "wb") as f:
#         f.write(image_data)
    
#     print("Graph saved as 'output_graph2.png'")
# except Exception as e:
#     print(f"An error occurred: {e}")



# Example Conversation
question = "hi"
config = {
    "configurable": {
        # The passenger_id is used in our flight tools to
        # fetch the user's flight information
        "passenger_id": "3442 587242",
        # Checkpoints are accessed by thread_id
        "thread_id": 84356,
    }
}
 

_printed = set()
events = part_2_graph.stream(
    {"messages": ("user", question)}, config, stream_mode="values"
    )
for event in events:
    _print_event(event, _printed)
snapshot = part_2_graph.get_state(config)
while snapshot.next:
    # We have an interrupt! The agent is trying to use a tool, and the user can approve or deny it
    # Note: This code is all outside of your graph. Typically, you would stream the output to a UI.
    # Then, you would have the frontend trigger a new run via an API call when the user has provided input.
    try:
        user_input = input(
            "Do you approve of the above actions? Type 'y' to continue;"
            " otherwise, explain your requested changed.\n\n"
        )
    except:
        user_input = "y"
    if user_input.strip() == "y":
        # Just continue
        result = part_2_graph.invoke(
            None,
            config,
        )
    else:
        # Satisfy the tool invocation by
        # providing instructions on the requested changes / change of mind
        result = part_2_graph.invoke(
            {
                "messages": [
                    ToolMessage(
                        tool_call_id=event["messages"][-1].tool_calls[0]["id"],
                        content=f"API call denied by user. Reasoning: '{user_input}'. Continue assisting, accounting for the user's input.",
                    )
                ]
            },
            config,
        )
    snapshot = part_2_graph.get_state(config)
